"""Local: sensors (read at L19 MLP input ~ h18), write directions (L19 output) and thresholds for job 4."""
import json

import numpy as np

from make_stats import W, layer_stats, load
from sensors import centred, plane, read

LAYER = 19
SIDES = {"neg": (0, 1), "pos": (4, 3)}
H, _, _, cls, pcls = load()
h_in = H[LAYER - 1]
mu, cos, M, P = layer_stats(H, cls, pcls, LAYER)
M_in = np.stack([h_in[cls == k].mean(0) for k in range(5)])
_, u1, u2 = plane(H, cls, LAYER - 1)
vecs = {"one": mu / np.linalg.norm(mu) / cos / np.sqrt(len(mu)), "neuproto": P[2] - (P[1] + P[3]) / 2,
        "s_pol": centred(mu, u1), "s_int": centred(mu, u2)}
scal = {}
for side, (very, plain) in SIDES.items():
    d = M_in[very] - M_in[plain]
    vecs[f"s_very_{side}"] = centred(mu, d / np.linalg.norm(d))
    vecs[f"w_very_{side}"] = P[very] - P[plain]
    r = read(h_in, vecs[f"s_very_{side}"])
    m = (pcls == very) | (pcls == plain)
    ts = np.percentile(r[m], np.arange(5, 96, 2.5))
    accs = [(np.where(r[m] > t, very, plain) == cls[m]).mean() for t in ts]
    scal[f"t_{side}"] = float(ts[int(np.argmax(accs))])
    scal[f"sd_{side}"] = float(r[m].std())
    print(side, "t", scal[f"t_{side}"], "sd", scal[f"sd_{side}"], "rule acc", max(accs), "model", (pcls[m] == cls[m]).mean(),
          "|w|", np.linalg.norm(vecs[f"w_very_{side}"]))
gen = (vecs["s_very_neg"] + vecs["s_very_pos"]) / 2
r = read(h_in, gen)
m = pcls != 2
is_very = np.isin(cls, (0, 4))
ts = np.percentile(r[m], np.arange(5, 96, 2.5))
accs = [((r[m] > t) == is_very[m]).mean() for t in ts]
scal["t_gen"], scal["sd_gen"] = float(ts[int(np.argmax(accs))]), float(r[m].std())
print("generic t", scal["t_gen"], "sd", scal["sd_gen"])
rp = read(h_in, vecs["s_pol"])
print("polarity reader by class", [round(float(rp[cls == k].mean()), 2) for k in range(5)], "one-read", read(h_in, vecs["one"]).mean())
names = list(vecs)
np.save(W / "v4.npy", np.stack([vecs[k] for k in names]).astype(np.float16))
(W / "v4_meta.json").write_text(json.dumps({"names": names, "scalars": scal}))
