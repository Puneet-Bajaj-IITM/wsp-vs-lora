"""Local: steering vectors for job 2. Row 0 of each layer block = cos-scaled unit mean direction."""
import numpy as np

from make_stats import W, layer_stats, load

H, _, _, cls, pcls = load()
vecs, names = [], []
for layer in (19, 17, 20):
    mu, cos, M, P = layer_stats(H, cls, pcls, layer)
    e_neu = M[2] - (M[1] + M[3]) / 2
    e_calm = ((M[1] - M[0]) + (M[3] - M[4])) / 2
    block = {"read": mu / np.linalg.norm(mu) / cos, "combo": e_neu + e_calm}
    if layer == 19:
        block.update(neu=e_neu, calm=e_calm, neuproto=P[2] - (P[1] + P[3]) / 2)
    for k, v in block.items():
        names.append(f"L{layer}_{k}"); vecs.append(v)
        print(names[-1], round(float(np.linalg.norm(v)), 3))
np.save(W / "v2.npy", np.stack(vecs).astype(np.float16))
(W / "v2_names.json").write_text(__import__("json").dumps(names))
