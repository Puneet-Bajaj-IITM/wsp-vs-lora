"""Job 2: dose-response of constant class-plane steering written by spare MLP neurons."""
import json
from pathlib import Path

import numpy as np
import torch

from wsp.harness import Lab
from wlib import NeuronWriter, constant_neuron

WORK = Path(__file__).resolve().parent
IDX = list(range(512))
N_SPARE = 4
NAMES = json.loads((WORK / "v2_names.json").read_text())
VECS = dict(zip(NAMES, np.load(WORK / "v2.npy").astype(np.float32)))
lab = Lab(edit=None)
shown = np.array([e["shown_option_ids"] for e in lab.examples("train")[:len(IDX)]])
out = {}


def run(tag, layer, vec):
    w = NeuronWriter(lab.layers[layer], N_SPARE)
    if vec is not None:
        constant_neuron(w, VECS[f"L{layer}_read"], vec)
    r = lab.forward("train", IDX, note=f"job2 {tag}", capture_layers=(layer, 20))
    w.restore()
    s = r["summary"]
    pc = shown[np.arange(len(IDX)), r["logp"].argmax(1)]
    print(tag, "acc", round(s["accuracy"], 4), "nll", round(s["nll"], 3), "predclass", np.bincount(pc, minlength=5),
          "byblock", s["by_block"], flush=True)
    out[tag] = r["logp"]
    out[tag + "_hL"] = r["hidden"][layer].astype(np.float16)
    out[tag + "_h20"] = r["hidden"][20].astype(np.float16)


with torch.no_grad():
    run("ctrl_L19", 19, None)
    for m in (1.5, 4.0):
        run(f"neu_L19_x{m}", 19, m * VECS["L19_neu"])
        run(f"calm_L19_x{m}", 19, m * VECS["L19_calm"])
    run("neuproto_L19_x1", 19, VECS["L19_neuproto"])
    for layer, mults in [(19, (1.5, 3.0)), (17, (1.5,)), (20, (1.5,))]:
        for m in mults:
            run(f"combo_L{layer}_x{m}", layer, m * VECS[f"L{layer}_combo"])
np.savez_compressed(WORK / "job2_out.npz", **out)
