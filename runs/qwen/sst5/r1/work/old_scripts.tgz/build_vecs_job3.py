"""Local: query-space class directions (in RMSNorm-ed residual space) for job 3."""
import json

import numpy as np

from make_stats import N_CLASSES, W, layer_stats, load

SOFT_T = 4.0
Q_LAYERS = (21, 22, 23)
H, logp, shown, cls, pcls = load()
n = len(cls)
gam = np.load(W / "job1_weights.npz")["ln1"]
lc = np.zeros_like(logp)
for i in range(n):
    lc[i, shown[i]] = logp[i]
soft = np.exp(lc / SOFT_T)
soft /= soft.sum(1, keepdims=True)


def normed(layer):
    h = H[layer - 1]
    rms = np.sqrt((h ** 2).mean(1, keepdims=True))
    return h / rms * gam[layer]


def soft_means(x):
    return np.stack([(soft[:, c:c + 1] * x).sum(0) / soft[:, c].sum() for c in range(N_CLASSES)])


vecs, names = [], []
for layer in Q_LAYERS:
    S = soft_means(normed(layer))
    block = {"qneu": S[2] - (S[1] + S[3]) / 2, "qcalm": ((S[1] - S[0]) + (S[3] - S[4])) / 2}
    for k, v in block.items():
        names.append(f"L{layer}_{k}"); vecs.append(v)
mu, cos, M, P = layer_stats(H, cls, pcls, 19)
names += ["L19_read", "L19_neuproto"]
vecs += [mu / np.linalg.norm(mu) / cos, P[2] - (P[1] + P[3]) / 2]
for nm, v in zip(names, vecs):
    print(nm, round(float(np.linalg.norm(v)), 3))
np.save(W / "v3.npy", np.stack(vecs).astype(np.float16))
(W / "v3_names.json").write_text(json.dumps(names))
