"""How much could an intensity-threshold rule beat the model's own very / non-very calls?"""
import numpy as np
from make_stats import load
from sensors import plane, centred, read
H, base, shown, cls, pcls = load(); n = len(cls)
np.set_printoptions(precision=3, suppress=True, linewidth=220)
half = np.arange(n) < 768
for L in [16, 17, 18, 19]:
    h = H[L]; mu = h.mean(0)
    for side, (a, b) in {"neg": (0, 1), "pos": (4, 3)}.items():
        m = (pcls == a) | (pcls == b)          # examples the model puts on this side
        model_acc = (pcls[m] == cls[m]).mean()
        for fit, ev in [(half, ~half), (~half, half)]:
            d = h[fit & (cls == a)].mean(0) - h[fit & (cls == b)].mean(0)   # very minus non-very, side specific
            r = read(h, centred(mu, d / np.linalg.norm(d)))
            ts = np.percentile(r[m & fit], np.arange(5, 96, 5))
            accs = [(np.where(r[m & fit] > t, a, b) == cls[m & fit]).mean() for t in ts]
            t = ts[int(np.argmax(accs))]
            print(f"L{L} {side} n{m.sum()} model acc {model_acc:.3f} (eval half {(pcls[m&ev]==cls[m&ev]).mean():.3f}) threshold rule heldout {(np.where(r[m & ev] > t, a, b) == cls[m & ev]).mean():.3f} t {t:.2f} frac very {(r[m&ev]>t).mean():.2f} | always non-very {(cls[m&ev]==b).mean():.3f}")
