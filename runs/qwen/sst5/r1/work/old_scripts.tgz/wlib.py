"""Neuron-level weight programming helpers (no gradients): overwrite low-norm SwiGLU neurons."""
import numpy as np
import torch

GAMMA_FLOOR = 0.05
GATE_OPEN = 6.0
HIDDEN = 1536
SQRT_D = float(np.sqrt(HIDDEN))


def spare_neurons(layer, count: int) -> list[int]:
    mlp = layer.mlp
    score = (mlp.gate_proj.weight.float().norm(dim=1) * mlp.up_proj.weight.float().norm(dim=1)
             * mlp.down_proj.weight.float().norm(dim=0))
    return torch.argsort(score)[:count].tolist()


def reader(layer, direction: np.ndarray) -> torch.Tensor:
    """Weight row w such that w . RMSNorm(h) == sqrt(d) * (direction . h) / |h|."""
    gamma = layer.post_attention_layernorm.weight.float()
    d = torch.tensor(direction, dtype=torch.float32, device=gamma.device)
    safe = gamma.abs() >= GAMMA_FLOOR
    return torch.where(safe, d / torch.where(safe, gamma, torch.ones_like(gamma)), torch.zeros_like(d))


class NeuronWriter:
    """Overwrites spare neurons of one layer; restore() puts the original weights back."""

    def __init__(self, layer, count: int):
        self.mlp = layer.mlp
        self.layer = layer
        self.idx = spare_neurons(layer, count)
        self.saved = [(self.mlp.gate_proj.weight[self.idx].clone(), self.mlp.up_proj.weight[self.idx].clone(),
                       self.mlp.down_proj.weight[:, self.idx].clone())]
        self.used = 0
        for j in self.idx:
            self.mlp.down_proj.weight[:, j] = 0

    def write(self, gate_dir: np.ndarray, up_dir: np.ndarray, out_vec: np.ndarray) -> None:
        j = self.idx[self.used]
        self.used += 1
        dtype = self.mlp.gate_proj.weight.dtype
        self.mlp.gate_proj.weight[j] = reader(self.layer, gate_dir).to(dtype)
        self.mlp.up_proj.weight[j] = reader(self.layer, up_dir).to(dtype)
        self.mlp.down_proj.weight[:, j] = torch.tensor(out_vec, dtype=torch.float32,
                                                       device=self.mlp.down_proj.weight.device).to(dtype)

    def restore(self) -> None:
        gate, up, down = self.saved[0]
        self.mlp.gate_proj.weight[self.idx] = gate
        self.mlp.up_proj.weight[self.idx] = up
        self.mlp.down_proj.weight[:, self.idx] = down


def constant_neuron(writer: NeuronWriter, read_dir: np.ndarray, out_vec: np.ndarray) -> None:
    """Gate and up both read read_dir (unit mean direction / mean cosine), giving ~GATE_OPEN on answer
    positions, so the neuron emits ~out_vec there."""
    read = read_dir * (GATE_OPEN / SQRT_D)
    silu_open = GATE_OPEN / (1 + np.exp(-GATE_OPEN))
    writer.write(read, read, out_vec / (silu_open * GATE_OPEN))
