"""Check realized pushes of job 4 against the intended sensor functions, and their effect on decisions."""
import json
import numpy as np
from make_stats import W, load
from sensors import read
H, base, shown, cls, pcls = load(); n = 512
o = np.load(W/"job4_out.npz")
META = json.loads((W/"v4_meta.json").read_text()); V = dict(zip(META["names"], np.load(W/"v4.npy").astype(np.float32))); S = META["scalars"]
np.set_printoptions(precision=2, suppress=True, linewidth=220)
sh = shown[:n]; c = cls[:n]; p0 = pcls[:n]; h18 = H[18][:n]
def pc(lp): return sh[np.arange(n), lp.argmax(1)]
r1 = read(h18, V["s_pol"])
for tag, m_gain in [("side_m1.5", 1.5), ("side_m3", 3.0)]:
    d = o[tag+"_hL"].astype(np.float32) - H[19][:n]; p = pc(o[tag])
    for side, sign, very, plain in (("neg", -1, 0, 1), ("pos", 1, 4, 3)):
        wv = V[f"w_very_{side}"]; m = sign * r1 > 2
        real = (d[m] @ wv) / (wv @ wv)
        want = m_gain * (read(h18[m], V[f"s_very_{side}"]) - S[f"t_{side}"]) / S[f"sd_{side}"]
        print(tag, side, "n", m.sum(), "corr realized~intended", np.corrcoef(real, want)[0,1].round(3), "slope", (real @ want / (want @ want)).round(3), "mean real", real.mean().round(2), "mean want", want.mean().round(2), "resid shift norm", np.linalg.norm(d[m], axis=1).mean().round(2))
        qs = np.percentile(want, [0, 25, 50, 75, 90, 100])
        for lo, hi in zip(qs[:-1], qs[1:]):
            mm = (want >= lo) & (want <= hi); i = np.where(m)[0][mm]
            print(f"   want [{lo:5.2f},{hi:5.2f}] n{len(i):3d} true very {np.mean(c[i]==very):.2f} base pred very {np.mean(p0[i]==very):.2f} -> edited pred very {np.mean(p[i]==very):.2f} neutral {np.mean(p[i]==2):.2f}")
d = o["tent_only_hL"].astype(np.float32) - H[19][:n]; wv = V["neuproto"]; real = d @ wv / (wv @ wv)
r2 = read(h18, V["s_int"]); want = 0.7 + 1.8 * np.clip(1 - np.abs(r1 + 1) / 3, 0, None) * (1 - 0.3 * r2)
print("tent: corr", np.corrcoef(real, want)[0,1].round(3), "slope", (real @ want / (want @ want)).round(3), "real q", np.percentile(real, [5, 50, 95]), "want q", np.percentile(want, [5, 50, 95]))
p = pc(o["tent_only"])
for lo, hi in [(-9, 0.5), (0.5, 1), (1, 2), (2, 3.5), (3.5, 99)]:
    mm = (real >= lo) & (real < hi)
    print(f"  realized dose [{lo},{hi}) n{mm.sum()} true neutral {np.mean(c[mm]==2):.2f} pred neutral {np.mean(p[mm]==2):.2f} acc base {np.mean(p0[mm]==c[mm]):.2f} acc edited {np.mean(p[mm]==c[mm]):.2f}")
