import json, numpy as np
from pathlib import Path
W = Path(__file__).resolve().parent
d = np.load(W/"job1_capture.npz"); H = d["H"].astype(np.float32); logp = d["logp"]; lab = d["labels"]
ex = [json.loads(l) for l in open(W.parents[1]/"data/processed/sst5/train.jsonl")][:len(lab)]
shown = np.array([e["shown_option_ids"] for e in ex])
cls = shown[np.arange(len(lab)), lab]
pred = logp.argmax(1); pcls = shown[np.arange(len(lab)), pred]
print("acc", (pred==lab).mean(), "nll", -logp[np.arange(len(lab)),lab].mean())
conf = np.zeros((5,5),int)
for t,p in zip(cls,pcls): conf[t,p]+=1
print("confusion rows=true cols=pred\n", conf)
# class-ordered logp
lc = np.zeros_like(logp)
for i in range(len(lab)): lc[i, shown[i]] = logp[i]
for T in [1,2,3,4,5,6,8]:
    q = logp/T; q = q - np.log(np.exp(q).sum(1,keepdims=True))
    print("T",T,"nll",-q[np.arange(len(lab)),lab].mean())
# class bias offline (upper bound of class-level steering)
print("mean class-ordered logp by true class\n", np.array([lc[cls==c].mean(0) for c in range(5)]).round(2))
best=None
import itertools
grid=[0,1,2,3,4,5,6,8]
for bn in grid:
  for bv in [-4,-3,-2,-1,0,1,2]:
    b=np.array([bv,0,bn,0,bv]); a=((lc+b).argmax(1)==cls).mean()
    if best is None or a>best[0]: best=(a,bn,bv)
print("best class bias (neutral, very)", best)
# layer diagnostics: between-class variance fraction for class and for predicted letter, 1-D valence
val = cls-2
for L in range(H.shape[0]):
    h = H[L]; mu = h.mean(0); hc = h-mu
    tot = (hc**2).sum()
    bc = sum((cls==c).sum()*((h[cls==c].mean(0)-mu)**2).sum() for c in range(5))/tot
    bl = sum((pred==c).sum()*((h[pred==c].mean(0)-mu)**2).sum() for c in range(5))/tot
    u = h[cls>=3].mean(0)-h[cls<=1].mean(0); u/=np.linalg.norm(u)
    p = hc@u; corr = np.corrcoef(p,val)[0,1]
    # nearest centroid (split-half) as a diagnostic of class information
    tr = np.arange(len(lab))<1024; cen = np.stack([h[tr&(cls==c)].mean(0) for c in range(5)])
    te=~tr; dist=((h[te][:,None,:]-cen[None])**2).sum(-1); nc=(dist.argmin(1)==cls[te]).mean()
    print(f"L{L-0 if L<28 else -1:>3} norm {np.linalg.norm(h,axis=1).mean():8.1f} cosmean {(h@mu/np.linalg.norm(h,axis=1)/np.linalg.norm(mu)).mean():.3f} classvar {bc:.4f} lettervar {bl:.4f} valcorr {corr:.3f} nc_acc {nc:.3f}")
