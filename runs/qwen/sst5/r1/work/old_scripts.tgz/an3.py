import json, numpy as np
from pathlib import Path
W = Path(__file__).resolve().parent
d = np.load(W/"job1_capture.npz"); H = d["H"].astype(np.float32); logp = d["logp"]; lab = d["labels"]
ex = [json.loads(l) for l in open(W.parents[1]/"data/processed/sst5/train.jsonl")][:len(lab)]
shown = np.array([e["shown_option_ids"] for e in ex]); n=len(lab)
cls = shown[np.arange(n), lab]; pred = logp.argmax(1); pcls = shown[np.arange(n), pred]
lc = np.zeros_like(logp)
for i in range(n): lc[i, shown[i]] = logp[i]
np.set_printoptions(precision=3, suppress=True, linewidth=200)
tr = np.arange(n)<1024; te=~tr
def acc(s, m=te): return (s[m].argmax(1)==cls[m]).mean()
print("base te", acc(lc), "bias(4,-3) te", acc(lc+np.array([-3,0,4,0,-3])))
for L in [17,18,19,20]:
    h = H[L]; M = np.stack([h[tr&(cls==c)].mean(0) for c in range(5)]); mu=h[tr].mean(0)
    U,S,Vt = np.linalg.svd(M-M.mean(0), full_matrices=False)
    for k in [2,4]:
        P = Vt[:k]; z=(h-mu)@P.T; Mz=(M-mu)@P.T
        sig2 = np.mean([((z[tr&(cls==c)]-Mz[c])**2).mean() for c in range(5)])
        sc = -((z[:,None]-Mz[None])**2).sum(-1)/(2*sig2)
        prior = np.log(np.bincount(cls[tr],minlength=5)/tr.sum())
        res=[]
        for lam in [0,0.1,0.2,0.3,0.5,1.0]:
            res.append((lam, round(acc(lc*lam+sc+prior),3), round(acc(lc*lam+sc+prior,tr),3)))
        print(f"L{L} k{k} centroid-only te {acc(sc+prior):.3f} | (lam on model logits, te, tr) {res}")
    # class composition along PC1 bins
    if L==19:
        v=(h-mu)@Vt[0]; w=(h-mu)@Vt[1]
        for lo,hi in [(-99,-8),(-8,-6),(-6,-4),(-4,-1),(-1,2),(2,5),(5,8),(8,10),(10,99)]:
            m=(v>=lo)&(v<hi); print(lo,hi,m.sum(), np.bincount(cls[m],minlength=5)/max(m.sum(),1), "pred", np.bincount(pcls[m],minlength=5)/max(m.sum(),1))
