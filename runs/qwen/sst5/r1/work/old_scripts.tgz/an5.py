"""Simulate sensor-gated neutral push from per-example dose-response (doses 0, 1, 2.5, 5)."""
import numpy as np
from make_stats import W, load, layer_stats
H, base, shown, cls, pcls = load(); n = 512
o2 = np.load(W/"job2_out.npz"); o3 = np.load(W/"job3_out.npz")
np.set_printoptions(precision=3, suppress=True, linewidth=220)
sh = shown[:n]; c = cls[:n]
def pc(lp): return sh[np.arange(n), lp.argmax(1)]
doses = [0, 1, 2.5, 5]
P = np.stack([pc(base[:n]), pc(o2["neuproto_L19_x1"]), pc(o3["neuproto_x2.5"]), pc(o3["neuproto_x5"])])
print("acc by dose", (P == c).mean(1))
for d, p in zip(doses, P):
    conf = np.zeros((5, 5), int)
    for t, q in zip(c, p): conf[t, q] += 1
    print("dose", d, "\n", conf)
# sensors at L18 (input of L19 MLP), stats from examples 512.. (held out from the simulated block)
h = H[18]; tr = np.arange(len(cls)) >= n
mu = h[tr].mean(0); M = np.stack([h[tr & (cls == k)].mean(0) for k in range(5)])
U, S, Vt = np.linalg.svd(M - M.mean(0), full_matrices=False)
z = (h - mu) @ Vt[:2].T
if (M[4]-M[0]) @ Vt[0] < 0: z[:, 0] *= -1
if (M[0]+M[4]-2*M[2]) @ Vt[1] < 0: z[:, 1] *= -1
Mz = np.stack([z[tr & (cls == k)].mean(0) for k in range(5)]); print("class means in plane\n", Mz)
best = []
for c0 in [-3, -2, -1, 0, 1]:
    for b in [0, 0.3, 0.6, 1.0]:
        s = -np.abs(z[:, 0] - c0) - b * z[:, 1]
        sv = s[:n]
        for q_hi in [70, 80, 85, 90]:
            for q_lo in [0, 30, 50]:
                t_hi = np.percentile(s[tr], q_hi); t_lo = np.percentile(s[tr], q_lo)
                for lo_d, mid_d, hi_d in [(0, 1, 2.5), (0, 0, 2.5), (0, 1, 5), (1, 1, 2.5), (0, 2.5, 5), (0,0,5),(1,2.5,5)]:
                    dose = np.where(sv >= t_hi, hi_d, np.where(sv >= t_lo, mid_d, lo_d))
                    pred = P[[doses.index(x) for x in dose], np.arange(n)]
                    best.append(((pred == c).mean(), c0, b, q_hi, q_lo, (lo_d, mid_d, hi_d), (pred == 2).sum()))
best.sort(key=lambda x: -x[0])
for r in best[:15]: print(r)
# sensor quality: neutral share among top-q of score on held-out
s = -np.abs(z[:, 0] + 1) - 0.6 * z[:, 1]
for q in [50, 70, 80, 90]:
    t = np.percentile(s, q); print("top", 100 - q, "% neutral share", (cls[s >= t] == 2).mean(), "recall", ((cls == 2) & (s >= t)).sum() / (cls == 2).sum())
