import json, numpy as np
from pathlib import Path
W = Path(__file__).resolve().parent
d = np.load(W/"job1_capture.npz"); H = d["H"].astype(np.float32); logp = d["logp"]; lab = d["labels"]
ex = [json.loads(l) for l in open(W.parents[1]/"data/processed/sst5/train.jsonl")][:len(lab)]
shown = np.array([e["shown_option_ids"] for e in ex]); n=len(lab)
cls = shown[np.arange(n), lab]; pred = logp.argmax(1); pcls = shown[np.arange(n), pred]
np.set_printoptions(precision=2, suppress=True, linewidth=200)
for L in [16,18,19,20]:
    h = H[L]; mu = h.mean(0)
    M = np.stack([h[cls==c].mean(0) for c in range(5)]); P = np.stack([h[pcls==c].mean(0) for c in [0,1,3,4]])
    print(f"--- L{L} |mu| {np.linalg.norm(mu):.1f} within-class std total {np.sqrt(sum(((h[cls==c]-M[c])**2).sum() for c in range(5))/n):.2f}")
    print("true-class mean dists\n", np.linalg.norm(M[:,None]-M[None],axis=-1))
    U,S,Vt = np.linalg.svd(M-M.mean(0), full_matrices=False); print("sv of class means", S)
    proj = (h-mu)@Vt[:3].T
    for c in range(5): print("true",c,"mean pc", proj[cls==c].mean(0), "std", proj[cls==c].std(0))
    for c in range(5): print("pred",c,"n",(pcls==c).sum(),"mean pc", proj[pcls==c].mean(0) if (pcls==c).sum() else None)
    # proxy: nearest predicted-class centroid agreement with model prediction
    cen = np.stack([h[pcls==c].mean(0) for c in range(5)])
    ag = (((h[:,None]-cen[None])**2).sum(-1).argmin(1)==pcls).mean(); print("proxy agreement nearest pred-centroid", ag)
    # 1D valence quantiles per class
    u = Vt[0]; v=(h-mu)@u
    for c in range(5): print("class",c,"valence q10/50/90", np.percentile(v[cls==c],[10,50,90]))
    for c in range(5):
        if (pcls==c).sum()>5: print("pred",c,"valence q10/50/90", np.percentile(v[pcls==c],[10,50,90]))
    # best 1D thresholds on valence (diagnostic of ceiling)
