"""Hand-built SwiGLU neuron circuits. All sensors are 'reader' directions: value = sqrt(d) * dir.h / |h|.

`one` reads ~1 at the answer position (mean residual direction). Neuron output = down * silu(gate) * up.
"""
import numpy as np

from wlib import GATE_OPEN, NeuronWriter

SHARPNESS = 4.0
SILU_OPEN = GATE_OPEN / (1 + np.exp(-GATE_OPEN))
CONST_GAIN = 1 / 0.7
SENSOR_GAIN = 1 / 0.8


def const_push(w: NeuronWriter, one, vec, amount):
    """~amount * vec at every answer position (gate and up both read `one`)."""
    w.write(GATE_OPEN * one, GATE_OPEN * one, vec * (amount * CONST_GAIN / (SILU_OPEN * GATE_OPEN)))


def linear_push(w: NeuronWriter, one, sensor, threshold, vec, gain):
    """gain * (sensor - threshold) * vec, signed (open gate, linear up)."""
    w.write(GATE_OPEN * one, sensor - threshold * one, vec * (gain * SENSOR_GAIN / SILU_OPEN))


def relu_push(w: NeuronWriter, one, sensor, threshold, up_dir, vec, gain):
    """gain * relu(sensor - threshold) * (up_dir reading) * vec."""
    w.write(SHARPNESS * (sensor - threshold * one), up_dir, vec * (gain * SENSOR_GAIN / SHARPNESS))


def step_gated_linear(w: NeuronWriter, one, pol, sign, center, half_width, sensor, threshold, vec, gain):
    """step(sign * (pol - center)) * gain * (sensor - threshold) * vec; step ramps 0->1 over 2*half_width."""
    up = sensor - threshold * one
    for edge, coef in ((-half_width, 1.0), (half_width, -1.0)):
        relu_push(w, one, sign * pol, sign * center + edge, up, vec, coef * gain / (2 * half_width))


def tent_push(w: NeuronWriter, one, pol, center, width, modulator, vec, peak):
    """peak * tent(pol; center, width) * (modulator reading) * vec; tent = three ReLUs."""
    for edge, coef in ((center - width, 1.0), (center, -2.0), (center + width, 1.0)):
        relu_push(w, one, pol, edge, modulator, vec, coef * peak / width)
