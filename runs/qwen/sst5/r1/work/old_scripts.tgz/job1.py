"""Job 1: base captures on train (all layers, answer position) plus weight statistics."""
from pathlib import Path

import numpy as np
import torch

from wsp.harness import Lab

WORK = Path(__file__).resolve().parent
PASS_SIZE = 512
N_CAPTURE_PASSES = 3
N_LAYERS = 28
CAPTURE = tuple(range(N_LAYERS)) + (-1,)

lab = Lab(edit=None)
logps, labels, hidden = [], [], {k: [] for k in CAPTURE}
for p in range(N_CAPTURE_PASSES):
    idx = list(range(p * PASS_SIZE, (p + 1) * PASS_SIZE))
    r = lab.forward("train", idx, note=f"job1 base capture train block {p}", capture_layers=CAPTURE)
    print(p, r["summary"], r["passes_left"], flush=True)
    logps.append(r["logp"]); labels.append(r["labels"])
    for k in CAPTURE:
        hidden[k].append(r["hidden"][k].astype(np.float16))
H = np.stack([np.concatenate(hidden[k]) for k in CAPTURE])
np.savez_compressed(WORK / "job1_capture.npz", H=H, logp=np.concatenate(logps), labels=np.concatenate(labels))

m = lab.model
layers = lab.layers
stats = {
    "ln1": np.stack([l.input_layernorm.weight.float().cpu().numpy() for l in layers]),
    "ln2": np.stack([l.post_attention_layernorm.weight.float().cpu().numpy() for l in layers]),
    "lnf": m.model.norm.weight.float().cpu().numpy(),
    "W_letters": m.lm_head.weight[lab.letters].float().cpu().numpy(),
    "letters": lab.letters.cpu().numpy(),
    "gate_norm": np.stack([l.mlp.gate_proj.weight.float().norm(dim=1).cpu().numpy() for l in layers]),
    "up_norm": np.stack([l.mlp.up_proj.weight.float().norm(dim=1).cpu().numpy() for l in layers]),
    "down_norm": np.stack([l.mlp.down_proj.weight.float().norm(dim=0).cpu().numpy() for l in layers]),
}
np.savez_compressed(WORK / "job1_weights.npz", **stats)
ex = lab.examples("train")[0]
from wsp.scoring import render_prompts
prompt = render_prompts(lab.tok, [ex])[0]
ids = lab.tok(prompt)["input_ids"]
print(repr(prompt))
print([(i, lab.tok.decode([i])) for i in ids])
for w in [" neutral", "neutral", " negative", " positive", " very", "very", "A", " A", "."]:
    print(repr(w), lab.tok.encode(w, add_special_tokens=False))
print({n: tuple(p.shape) for n, p in layers[0].named_parameters()})
print("eps", layers[0].input_layernorm.eps if hasattr(layers[0].input_layernorm, "eps") else None)
