import json, sys, numpy as np
from make_stats import W, load, layer_stats
H, base, shown, cls, pcls = load()
o = np.load(W / sys.argv[1]); n = 512
np.set_printoptions(precision=2, suppress=True, linewidth=220)
sh = shown[:n]; c = cls[:n]
def lcof(lp):
    lc = np.zeros_like(lp)
    for i in range(n): lc[i, sh[i]] = lp[i]
    return lc
b = lcof(base[:n]); print("base acc", (b.argmax(1)==c).mean(), "pred", np.bincount(b.argmax(1),minlength=5))
for k in o.files:
    if k.endswith("_hL") or k.endswith("_h20"): continue
    lc = lcof(o[k]); p = lc.argmax(1)
    raw = o[k] - 0  # letter logp
    dl = (lc - b); dl = dl - dl.mean(1, keepdims=True)
    line = f"{k:18s} acc {(p==c).mean():.3f} nll {-lc[np.arange(n),c].mean():.2f} pred {np.bincount(p,minlength=5)} dclasslogit {dl.mean(0)} flips {(p!=b.argmax(1)).mean():.2f}"
    if k + "_hL" in o.files:
        L = int(k.split("_L")[1].split("_")[0]); sft = o[k+"_hL"].astype(np.float32)[:n] - H[L][:n]
        line += f" | shift norm mean {np.linalg.norm(sft.mean(0)):.2f} per-ex sd {np.linalg.norm(sft-sft.mean(0),axis=1).mean():.2f}"
    print(line)
