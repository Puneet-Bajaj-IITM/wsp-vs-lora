"""Job 4: intensity re-mapping (very vs non-very) and tent-gated neutral push, written at the L19 MLP."""
import json
from pathlib import Path

import numpy as np
import torch

from wsp.harness import Lab
from wlib import NeuronWriter
import circuits as C

WORK = Path(__file__).resolve().parent
IDX = list(range(512))
LAYER = 19
N_SPARE = 12
META = json.loads((WORK / "v4_meta.json").read_text())
V = dict(zip(META["names"], np.load(WORK / "v4.npy").astype(np.float32)))
S = META["scalars"]
NEU_CONST, NEU_PEAK, TENT_CENTER, TENT_WIDTH, TENT_INT_SLOPE = 0.7, 2.5, -1.0, 3.0, 0.3
STEP_CENTER, STEP_HALF = 0.0, 1.0
lab = Lab(edit=None)
shown = np.array([e["shown_option_ids"] for e in lab.examples("train")[:len(IDX)]])
out, accs = {}, {}


def very_generic(w, m):
    sensor = (V["s_very_neg"] + V["s_very_pos"]) / 2
    C.linear_push(w, V["one"], sensor, S["t_gen"], (V["w_very_neg"] + V["w_very_pos"]) / 2, m / S["sd_gen"])


def very_sided(w, m):
    for side, sign in (("neg", -1.0), ("pos", 1.0)):
        C.step_gated_linear(w, V["one"], V["s_pol"], sign, STEP_CENTER, STEP_HALF, V[f"s_very_{side}"],
                            S[f"t_{side}"], V[f"w_very_{side}"], m / S[f"sd_{side}"])


def neutral_const(w):
    C.const_push(w, V["one"], V["neuproto"], NEU_CONST)


def neutral_tent(w):
    neutral_const(w)
    C.tent_push(w, V["one"], V["s_pol"], TENT_CENTER, TENT_WIDTH, V["one"] - TENT_INT_SLOPE * V["s_int"],
                V["neuproto"], NEU_PEAK - NEU_CONST)


def run(tag, *builders):
    w = NeuronWriter(lab.layers[LAYER], N_SPARE)
    for b in builders:
        b(w)
    r = lab.forward("train", IDX, note=f"job4 {tag}", capture_layers=(LAYER,))
    w.restore()
    s = r["summary"]
    pc = shown[np.arange(len(IDX)), r["logp"].argmax(1)]
    print(tag, "acc", round(s["accuracy"], 4), "nll", round(s["nll"], 3), "predclass", np.bincount(pc, minlength=5),
          "byblock", s["by_block"], flush=True)
    out[tag] = r["logp"]
    out[tag + "_hL"] = r["hidden"][LAYER].astype(np.float16)
    accs[tag] = s["accuracy"]


VERY = {"gen_m0.6": lambda w: very_generic(w, 0.6), "gen_m1.5": lambda w: very_generic(w, 1.5),
        "side_m1.5": lambda w: very_sided(w, 1.5), "side_m3": lambda w: very_sided(w, 3.0)}
with torch.no_grad():
    for tag, builder in VERY.items():
        run(tag, builder)
    best = max(VERY, key=lambda k: accs[k])
    print("best very-remap:", best, flush=True)
    run("tent_only", neutral_tent)
    run(f"{best}+neuconst", VERY[best], neutral_const)
    run(f"{best}+tent", VERY[best], neutral_tent)
np.savez_compressed(WORK / "job4_out.npz", **out)
