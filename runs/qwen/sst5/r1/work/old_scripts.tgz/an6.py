"""Simulate a tent-gated neutral push: dose = d0 + tent(r1; c0, w) * (u0 - b * r2)."""
import itertools
import numpy as np
from make_stats import W, load, layer_stats
from sensors import plane, centred, read
H, base, shown, cls, pcls = load(); n = 512
o2 = np.load(W/"job2_out.npz"); o3 = np.load(W/"job3_out.npz")
np.set_printoptions(precision=3, suppress=True, linewidth=220)
sh = shown[:n]; c = cls[:n]
def pc(lp): return sh[np.arange(n), lp.argmax(1)]
P = np.stack([pc(base[:n]), pc(o2["neuproto_L19_x1"]), pc(o3["neuproto_x2.5"]), pc(o3["neuproto_x5"])])
def outcome(dose):
    k = np.where(dose < 0.5, 0, np.where(dose < 1.75, 1, np.where(dose < 3.75, 2, 3)))
    return P[k, np.arange(n)]
mu, u1, u2 = plane(H, cls, 18)
r1 = read(H[18], centred(mu, u1)); r2 = read(H[18], centred(mu, u2))
print("reader stats by class (r1 mean, r2 mean):", [(round(r1[cls==k].mean(),2), round(r2[cls==k].mean(),2)) for k in range(5)], "sd", r1.std().round(2), r2.std().round(2))
# direction comparison
_, _, M19, P19 = layer_stats(H, cls, pcls, 19)
lc = np.zeros_like(base)
for i in range(len(cls)): lc[i, shown[i]] = base[i]
soft = np.exp(lc/4); soft /= soft.sum(1, keepdims=True)
S = np.stack([(soft[:, k:k+1]*H[19]).sum(0)/soft[:, k].sum() for k in range(5)])
cosf = lambda a, b: float(a@b/np.linalg.norm(a)/np.linalg.norm(b))
neuproto = P19[2]-(P19[1]+P19[3])/2; softneu = S[2]-(S[1]+S[3])/2; eneu = M19[2]-(M19[1]+M19[3])/2
print("cos neuproto~softneu", cosf(neuproto, softneu), "neuproto~eneu", cosf(neuproto, eneu), "softneu~eneu", cosf(softneu, eneu), "norms", np.linalg.norm(neuproto), np.linalg.norm(softneu), np.linalg.norm(eneu))
A1, A2 = r1[:n], r2[:n]
res = []
for c0, w, d0, peak, b in itertools.product([-2, -1.5, -1, -0.5, 0, 0.5], [1, 1.5, 2, 3, 4], [0, 1], [1.5, 2.5, 4, 6], [0, 0.3, 0.6, 1.0]):
    tent = np.clip(1 - np.abs(A1 - c0)/w, 0, None)
    dose = d0 + tent * (peak - d0) * np.clip(1 - b * A2, 0, None)
    p = outcome(dose); res.append(((p == c).mean(), c0, w, d0, peak, b, int((p == 2).sum()), int(((p == 2) & (c == 2)).sum())))
res.sort(key=lambda x: -x[0])
for r in res[:20]: print(r)
