import json, numpy as np
from pathlib import Path
W = Path(__file__).resolve().parent
d = np.load(W/"job1_capture.npz"); H = d["H"].astype(np.float32); logp = d["logp"]; lab = d["labels"]
ex = [json.loads(l) for l in open(W.parents[1]/"data/processed/sst5/train.jsonl")][:len(lab)]
shown = np.array([e["shown_option_ids"] for e in ex]); n=len(lab)
cls = shown[np.arange(n), lab]; pred = logp.argmax(1); pcls = shown[np.arange(n), pred]
np.set_printoptions(precision=2, suppress=True, linewidth=200)
for L in [17,19,20]:
    h=H[L]; mu=h.mean(0); M=np.stack([h[cls==c].mean(0) for c in range(5)])
    U,S,Vt=np.linalg.svd(M-M.mean(0),full_matrices=False); z=(h-mu)@Vt[:2].T
    print("L",L)
    for name,m in [("neg side z1<-3",z[:,0]<-3),("pos side z1>4",z[:,0]>4),("mid",(z[:,0]>=-3)&(z[:,0]<=4))]:
        print(name)
        qs=np.percentile(z[m,1],[0,12.5,25,37.5,50,62.5,75,87.5,100])
        for lo,hi in zip(qs[:-1],qs[1:]):
            mm=m&(z[:,1]>=lo)&(z[:,1]<=hi)
            print(f"  z2 [{lo:6.1f},{hi:6.1f}] n{mm.sum():4d} true {np.bincount(cls[mm],minlength=5)/mm.sum()} pred {np.bincount(pcls[mm],minlength=5)/mm.sum()}")
