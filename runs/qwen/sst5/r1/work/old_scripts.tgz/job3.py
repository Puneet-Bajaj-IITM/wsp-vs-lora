"""Job 3: class bias injected into the binding queries (q_proj.bias at L21-23), plus two controls."""
import json
from pathlib import Path

import numpy as np
import torch

from wsp.harness import Lab
from wlib import NeuronWriter, constant_neuron

WORK = Path(__file__).resolve().parent
IDX = list(range(512))
N_SPARE = 4
NEUTRAL_TOKEN = " neutral"
SHIFT_GAIN = 1 / 0.7
NAMES = json.loads((WORK / "v3_names.json").read_text())
VECS = dict(zip(NAMES, np.load(WORK / "v3.npy").astype(np.float32)))
lab = Lab(edit=None)
shown = np.array([e["shown_option_ids"] for e in lab.examples("train")[:len(IDX)]])
out = {}


def measure(tag):
    r = lab.forward("train", IDX, note=f"job3 {tag}", capture_layers=(20, 23))
    s = r["summary"]
    pc = shown[np.arange(len(IDX)), r["logp"].argmax(1)]
    print(tag, "acc", round(s["accuracy"], 4), "nll", round(s["nll"], 3), "predclass", np.bincount(pc, minlength=5),
          "byblock", s["by_block"], flush=True)
    out[tag] = r["logp"]


def qbias(tag, layers, a_neu, a_calm):
    saved = {}
    for layer in layers:
        attn = lab.layers[layer].self_attn
        saved[layer] = attn.q_proj.bias.clone()
        d = a_neu * VECS[f"L{layer}_qneu"] + a_calm * VECS[f"L{layer}_qcalm"]
        d = torch.tensor(d, device=attn.q_proj.weight.device)
        delta = attn.q_proj.weight.float() @ d
        if layer == layers[0]:
            print(tag, "L", layer, "|bias|", float(attn.q_proj.bias.float().norm()), "|delta|", float(delta.norm()))
        attn.q_proj.bias += delta.to(attn.q_proj.bias.dtype)
    measure(tag)
    for layer in layers:
        lab.layers[layer].self_attn.q_proj.bias.copy_(saved[layer])


def neuproto(tag, mult):
    w = NeuronWriter(lab.layers[19], N_SPARE)
    constant_neuron(w, VECS["L19_read"], mult * SHIFT_GAIN * VECS["L19_neuproto"])
    measure(tag)
    w.restore()


def embed_scale(tag, factor):
    emb = lab.model.get_input_embeddings().weight
    tid = lab.tok.encode(NEUTRAL_TOKEN, add_special_tokens=False)[0]
    saved = emb[tid].clone()
    emb[tid] *= factor
    measure(tag)
    emb[tid] = saved


with torch.no_grad():
    qbias("q21_neu2", (21,), 2, 0)
    qbias("q21_neu6", (21,), 6, 0)
    qbias("q21_neu6_calm6", (21,), 6, 6)
    qbias("q21_neu15_calm15", (21,), 15, 15)
    qbias("q21-23_neu3_calm3", (21, 22, 23), 3, 3)
    qbias("q21-23_neu8_calm8", (21, 22, 23), 8, 8)
    neuproto("neuproto_x2.5", 2.5)
    neuproto("neuproto_x5", 5.0)
    embed_scale("emb_neutral_x1.5", 1.5)
np.savez_compressed(WORK / "job3_out.npz", **out)
